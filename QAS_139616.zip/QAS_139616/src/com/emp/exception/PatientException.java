package com.emp.exception;

/*******************************************************************************************************
- Exception Name	:	    PatientException
- Author			:	Jainisha Mangtani
- Creation Date	:	     30/11/2017
- Description		:	Exception
********************************************************************************************************/
public class PatientException  extends Exception 
{
		public PatientException(String message) {
			super(message);	}
}