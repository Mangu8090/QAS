package com.capgemini.doctors.ui;

import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;
import com.emp.exception.PatientException;


/*******************************************************************************************************
- Function Name	:	    main(String[] args)
- Input Parameters	:	(String[] args)
- Return Type		:	void
- Throws			:  	PatientException
- Author			:	Jainisha Mangtani
- Creation Date	:	     30/11/2017
- Description		:	Description of details and functions
********************************************************************************************************/
public class Client {
public static void main(String[] args) {
	
        int n1;
		do{
	System.out.println("1.Book Doctor Appointment");
	 System.out.println("2.View Doctor Appointment");
	 System.out.println("3.Exit");
	  
	System.out.println("Enter choice");
	Scanner sc= new Scanner(System.in);
						
	int n= sc.nextInt();
	switch(n)
	{
	
	case 1:
		System.out.println("Enter Name of patient");
		String name= sc.next();
		System.out.println("Enter phone number");
		String phoneno= sc.next();
		System.out.println("Enter Email");
		String mailid= sc.next();
		System.out.println("Enter age");
		int age= sc.nextInt();
		System.out.println("Enter gender");
		String gender= sc.next();
		System.out.println("Enter Problem name");
		String prob= sc.next();
		
		
		DoctorAppointment patientbean=new DoctorAppointment();
		patientbean.setPatientName(name);
		patientbean.setPhoneNumber(phoneno);
		patientbean.setEmail(mailid);
		patientbean.setAge(age);
		patientbean.setGender(gender);
		patientbean.setProblemName(prob);
		//System.out.println(patientbean.getProblem_name());
		IDoctorAppointmentService service=new DoctorAppointmentService();
		try{
			
			if(service.validateDetails(patientbean)){
		int id=service.addDoctorAppointmentDetails(patientbean);
		System.out.println("Your Doctor Appointment has been successfully registered="+id);
			}
			else
			{
				System.out.println("Details cannot be added");
			}
	}
		catch (PatientException e) 
		{	
			
			System.out.println(e.getMessage());
		}
	  break;
	  
	case 2:
		System.out.println("Enter the appointment Id : ");
		int Id = sc.nextInt();
		IDoctorAppointmentService service1=new DoctorAppointmentService();
		
		try {
			DoctorAppointment bean= service1.viewStatus(Id);
			System.out.println("The details of id : "+Id+"\n"+"***************************");
			System.out.println(bean.toString());
		}
		catch (PatientException e) 
		{
			System.out.println(e.getMessage());
		}
		break;
		
	
	}System.out.println("Do you want to continue\n1.yes2.no");
	Scanner sc1= new Scanner(System.in);
	n1=sc1.nextInt();
	}
	while(n1==1);
	}
    
}

