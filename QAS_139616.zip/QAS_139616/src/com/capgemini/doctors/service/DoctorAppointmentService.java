package com.capgemini.doctors.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.emp.exception.PatientException;

public class DoctorAppointmentService implements IDoctorAppointmentService{

	 
	
	public int addDoctorAppointmentDetails(DoctorAppointment bean) throws PatientException{
		IDoctorAppointmentDao dao = new DoctorAppointmentDao();
		int id= dao.addDoctorAppointmentDetails(bean);
		return id;
	}
	public DoctorAppointment viewStatus(int id) throws PatientException {
		IDoctorAppointmentDao dao = new DoctorAppointmentDao();
		DoctorAppointment bean = new DoctorAppointment();
		bean = dao.viewStatus(id);
		return bean;
	}
		
	/*******************************************************************************************************
	 - Function Name	:	validatingClientDetails(DoctorAppointment bean)
	 - Input Parameters	:	DoctorAppointment bean
	 - Return Type		:	DoctorAppointment
	 - Throws			:  	PatientException
	 - Author			:	Jainisha Mangtani
	 - Creation Date	:	30/11/2017
	 - Description		:	validating Client
	 ********************************************************************************************************/
	@Override
	public boolean validateName(String name) throws PatientException 
	{
		Pattern pattern =Pattern.compile("[A-Z][A-Za-z]{1,19}");
		Matcher matcher= pattern.matcher(name);
		return matcher.matches();
	}

	@Override
	public boolean validatePhone(String phone) throws PatientException 
	{
		Pattern pattern =Pattern.compile("[1-9][0-9]{9}");
		Matcher matcher= pattern.matcher(String.valueOf(phone));
		return matcher.matches();
		
	}

	@Override
	public boolean validateEmail(String email) throws PatientException  
	{
		Pattern pattern =Pattern.compile("[a-z0-9/_.+-]+@[a-z]{2,6}+.[a-z]{2,4}$");
		Matcher matcher= pattern.matcher(email);
		return matcher.matches();
	}	
	
	
	boolean validate = false;
	List<String> validationErrors = new ArrayList<String>();

	@Override
	public boolean validateDetails(DoctorAppointment bean) throws PatientException 
	{
	if(!(validateName(bean.getPatientName()) ))
	{
		validationErrors.add("\n Employee Name Should Be In Alphabets and max 20 characters long! \n");
	}
	
	if(!(validatePhone(bean.getPhoneNumber())))
	{
		validationErrors.add("\nContact number should be exact 10 digits! \n");
	}
	if(!(validateEmail(bean.getEmail())))
	{
		validationErrors.add("\n Not a valid email id \n" );
	}
	
	if(!validationErrors.isEmpty())
	{
		throw new PatientException(validationErrors +"");
	}
	else
	{
		validate = true;
	}
	return validate;
}
}


