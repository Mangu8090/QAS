package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.emp.exception.PatientException;

public interface IDoctorAppointmentService {

	public int addDoctorAppointmentDetails(DoctorAppointment bean)
			throws PatientException;

	public DoctorAppointment viewStatus(int id) throws PatientException;

	public boolean validateDetails(DoctorAppointment bean)
			throws PatientException;

	boolean validateEmail(String email) throws PatientException;

	boolean validatePhone(String phone) throws PatientException;

	boolean validateName(String name) throws PatientException;
}
