package com.capgemini.doctors.dao;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.emp.exception.PatientException;

public interface IDoctorAppointmentDao {
 
	public int addDoctorAppointmentDetails(DoctorAppointment bean) throws PatientException;
	public DoctorAppointment viewStatus(int id) throws PatientException;
	
	
}
