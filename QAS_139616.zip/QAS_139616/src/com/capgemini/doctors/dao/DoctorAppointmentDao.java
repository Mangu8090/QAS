package com.capgemini.doctors.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.emp.exception.PatientException;
import com.emp.util.DBConnection;

public class DoctorAppointmentDao implements IDoctorAppointmentDao{

	Scanner sc = new Scanner(System.in);
	
	Logger logger = Logger.getLogger(DoctorAppointmentDao.class);
	
	public DoctorAppointmentDao()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	
	
	
		/*******************************************************************************************************
		 - Function Name	:	addClientDetails(DoctorAppointment bean)
		 - Input Parameters	:	DoctorAppointment bean
		 - Return Type		:	Integer
		 - Throws			:  	PatientException
		 - Author			:	Jainisha Mangtani
		 - Creation Date	:	30/11/2017
		 - Description		:	Adding Client
		 ********************************************************************************************************/
	
	public int generateEmployeeId()
	{
		int id=0;
		Connection  con = null;
		String str= "select seq_appointment_id.nextval from dual";
		try 
		{
			logger.info("connecting to database for generating id..");
			con=DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(str);
			rs.next();
			id=rs.getInt(1);

			logger.info("id generated..\n");
		}
		catch (Exception e) 
		{
			
			logger.info("id can not be generated..\n");
		}
		return id;
	}
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment bean)
			throws PatientException{

				int id=0;
				Connection con= null;
				ResultSet rs= null;
				String cmd="insert into doctor_appointment values(?,?,?,sysdate+1,?,?,?,?,?,?)";
				String doctorName=null;
				String status=null;
				id=generateEmployeeId();
				
				try 
				{
					logger.debug("connecting to database for adding client details..");
					con=DBConnection.getConnection();
				
					String problemName=bean.getProblemName();
					
					if(problemName.equalsIgnoreCase("Heart"))
					{
						status="Approved";
						doctorName="Dr.Brijesh Kumar";
					}
					else if(problemName.equalsIgnoreCase("Gynecology"))
					{
						status="Approved";
						doctorName="Dr.Sharda Singh";
					}
					else if(problemName.equalsIgnoreCase("Diabetes"))
					{
						status="Approved";
						doctorName="Dr.Heena Khan";
					}
					else if(problemName.equalsIgnoreCase("ENT"))
					{
						status="Approved";
						doctorName="Dr.Paras mal";
					}
					else if(problemName.equalsIgnoreCase("Bone"))
					{
						status="Approved";
						doctorName="Dr.Renuka Kher";
					}
					else if(problemName.equalsIgnoreCase("Dermatology"))
					{
						status="Approved";
						doctorName="Dr.Kanika Kapoor";
					}
					else
					{
						status="Disapproved";
					}
					
                    PreparedStatement ps = con.prepareStatement(cmd);
					
					ps.setInt(1,id);
					ps.setString(2,bean.getPatientName());
					ps.setString(3,bean.getPhoneNumber());
					ps.setString(4, bean.getEmail());
					ps.setInt(5, bean.getAge());
					ps.setString(6, bean.getGender());
					ps.setString(7, bean.getProblemName());
					ps.setString(8, doctorName);
					ps.setString(9, status);
					int n=ps.executeUpdate();
					System.out.println(n);
					if(n==0)
					{
						logger.error("exception while adding database..\n");
						throw new PatientException("unable to insert details");
					}
					else
					{
						
						logger.info("details added..\n");
					}
					
					con.close();
				}
					
				catch (Exception e) 
				{
					logger.error("exception while adding details..\n");
					throw new PatientException("Details cannot be added");
				} 
				return id;
			}

	/*******************************************************************************************************
	 - Function Name	:	viewClientDetails(int id)
	 - Input Parameters	:	int id
	 - Return Type		:	Integer
	 - Throws			:  	PatientException
	 - Author			:	Jainisha Mangtani
	 - Creation Date	:	30/11/2017
	 - Description		:	viewing Client
	 ********************************************************************************************************/
	@Override
	public DoctorAppointment viewStatus(int id) throws PatientException {
		Connection con= null;
		Statement stmt =null;
		DoctorAppointment bean= new DoctorAppointment();
		
		try {
			
			logger.debug("connecting to database for viewing status..");
			con=DBConnection.getConnection();
			String cmd="select patient_name,appointment_status,doctor_name,date_of_appointment from doctor_appointment where appointment_id ="+ id;
			 stmt =con.createStatement();
			
			 ResultSet result =stmt.executeQuery(cmd);
			 if(result.next())
				{
				 	bean.setPatientName(result.getString(1));
					bean.setAppointmentStatus(result.getString(2));
					bean.setDoctorName(result.getString(3));
					bean.setDateOfAppointment(result.getDate(4));
					logger.info("details fetched from doctor appointment table..\n");	
				}
			 else
			 {
				 logger.error("exception while fetching details..\n");
				 throw new PatientException("Id not found!");
			 }
		}
		 catch (SQLException e) 
		{
			 logger.error("database error!..\n");
			 throw new PatientException("database error!");
		}
		return bean;	
	}
}
