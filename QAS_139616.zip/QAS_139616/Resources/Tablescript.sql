

SQL> CREATE TABLE doctor_appointment(appointment_id NUMBER(4) PRIMARY KEY,patien
t_name VARCHAR2(20),phone_number VARCHAR2(10),date_of_appointment DATE,email VAR
CHAR2(50),age NUMBER(2),gender VARCHAR2(6),problem_name VARCHAR2(25),doctor_name
 VARCHAR2(25),appointment_status VARCHAR2(11));

Table created.

SQL> commit;

Commit complete.

SQL> CREATE SEQUENCE seq_appointment_id start with 1001;

Sequence created.

