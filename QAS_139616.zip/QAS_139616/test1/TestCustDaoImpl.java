import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.emp.exception.PatientException;


public class TestCustDaoImpl 
{
	static DoctorAppointmentDao Dao;
	static DoctorAppointment Bean;
	
	@BeforeClass
	public static void beforeClass()
	{
		Dao =new DoctorAppointmentDao();
		Bean = new DoctorAppointment();
	}
	
	@Test
	public void testaddDoctorAppointmentDetails() throws PatientException
	{
		assertNotNull(Dao.addDoctorAppointmentDetails(Bean));
	}
	
	
	@Test
	public void testaddDoctorAppointmentDetails1() throws PatientException
	{
		Bean.setPatientName("Shh");
	    Bean.setPhoneNumber("9856989568");
	    Bean.setEmail("bac@gmail.com");
		Bean.setAge(45);
		Bean.setGender("f");
		int id = Dao.addDoctorAppointmentDetails(Bean);
		assertTrue(id>0);
	}
	
	
	
	@Test
	public void testViewStatusById() throws PatientException
	{
		assertNotNull(Dao.viewStatus(1030));
	}
	
	@Test
	public void testViewMobById1() throws PatientException {
		assertEquals("Shhh",Dao.viewStatus(1030).getPatientName());
	}
	
	
}
